# Copyright (c) 2021, Frappe and Contributors
# See LICENSE

# import frappe
import unittest


class TestUnicommerceChannel(unittest.TestCase):
	pass
