# Copyright (c) 2018, Frappe Technologies Pvt. Ltd. and contributors
# For license information, please see LICENSE

# import frappe
from frappe.model.document import Document


class ShopifyWebhooks(Document):
	pass
