# Copyright (c) 2021, Frappe and Contributors
# See LICENSE

import json
import unittest

from ecommerce_integrations.shopify.order import sync_sales_order


class TestOrder(unittest.TestCase):
	def test_sync_with_variants(self):
		pass
