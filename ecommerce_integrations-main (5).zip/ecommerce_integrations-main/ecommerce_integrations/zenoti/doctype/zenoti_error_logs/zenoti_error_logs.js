// Copyright (c) 2021, Frappe and contributors
// For license information, please see LICENSE

frappe.ui.form.on('Zenoti Error Logs', {
	// refresh: function(frm) {

	// }
});
