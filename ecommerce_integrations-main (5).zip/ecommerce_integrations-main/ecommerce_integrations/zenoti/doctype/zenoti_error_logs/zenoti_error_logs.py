# Copyright (c) 2021, Frappe and contributors
# For license information, please see LICENSE

# import frappe
from frappe.model.document import Document


class ZenotiErrorLogs(Document):
	pass
