frappe.listview_settings["Ecommerce Item"] = {
	hide_name_column: true,
}
