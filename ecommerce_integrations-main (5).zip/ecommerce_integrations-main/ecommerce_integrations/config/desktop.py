from frappe import _


def get_data():
	return [
		{
			"module_name": "Ecommerce Integrations",
			"color": "grey",
			"icon": "octicon octicon-file-directory",
			"type": "module",
			"label": _("Ecommerce Integrations"),
		}
	]
