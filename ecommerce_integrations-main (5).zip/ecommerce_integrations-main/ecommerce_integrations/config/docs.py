"""
Configuration for docs
"""

# source_link = "https://github.com/[org_name]/ecommerce_integrations"
# docs_base_url = "https://[org_name].github.io/ecommerce_integrations"
# headline = "App that does everything"
# sub_heading = "Yes, you got that right the first time, everything"


def get_context(context):
	context.brand_html = "Ecommerce Integrations"
